from django.apps import AppConfig


class RecruiterConfig(AppConfig):
    name = 'recruiter'

from django.contrib import admin
from .models import databank

admin.site.register(databank)
# admin.site.register()
# admin.site.register()
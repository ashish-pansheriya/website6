from django.contrib import admin
from .models import cashtreats


admin.site.register(cashtreats)
# Register your models here.
